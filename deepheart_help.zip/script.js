// Global JavaScript functions for DeepHeart AI Digital Human Platform

// Initialize all functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initMobileMenu();
    initSmoothScrolling();
    initFloatingAnimation();
    initParticleBackground();
    initInteractiveElements();
});

// Mobile Menu Toggle Functionality
function initMobileMenu() {
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuToggle && mobileMenu) {
        mobileMenuToggle.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
            const icon = mobileMenuToggle.querySelector('i');
            
            if (mobileMenu.classList.contains('hidden')) {
                if (icon) icon.setAttribute('data-lucide', 'menu');
            } else {
                if (icon) icon.setAttribute('data-lucide', 'x');
            }
            
            // Reinitialize Lucide icons if available
            if (window.lucide) {
                lucide.createIcons();
            }
        });
    }
}

// Smooth Scrolling for Anchor Links
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const headerHeight = document.querySelector('nav') ? document.querySelector('nav').offsetHeight : 0;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Floating Animation for Hero Section Elements
function initFloatingAnimation() {
    const floatingElements = document.querySelectorAll('.floating-animation');
    
    floatingElements.forEach(element => {
        // Apply random delay to stagger animations
        const delay = Math.random() * 2;
        element.style.animationDelay = `${delay}s`;
    });
}

// Particle Background Effect
function initParticleBackground() {
    const container = document.getElementById('particles-container');
    
    if (container) {
        const particleCount = 30;
        
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');
            
            // Random size between 2px and 6px
            const size = Math.random() * 4 + 2;
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;
            
            // Random position
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.top = `${Math.random() * 100}%`;
            
            // Random color
            const colors = ['rgba(79, 70, 229, 0.5)', 'rgba(139, 92, 246, 0.5)', 'rgba(236, 72, 153, 0.5)'];
            particle.style.background = colors[Math.floor(Math.random() * colors.length)];
            
            // Random animation delay and duration
            particle.style.animationDelay = `${Math.random() * 8}s`;
            particle.style.animationDuration = `${Math.random() * 10 + 5}s`;
            
            container.appendChild(particle);
        }
    }
}

// Interactive Elements Animation
function initInteractiveElements() {
    const interactiveElements = document.querySelectorAll('.interactive-element');
    
    interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            element.style.transform = 'scale(1.05)';
            element.style.transition = 'transform 0.3s ease';
        });
        
        element.addEventListener('mouseleave', () => {
            element.style.transform = 'scale(1)';
        });
    });
}

// Form Validation Helper
function validateForm(formId, validationRules) {
    const form = document.getElementById(formId);
    
    if (!form) return;
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        let isValid = true;
        
        // Apply validation rules
        Object.entries(validationRules).forEach(([fieldName, rule]) => {
            const field = form.querySelector(`[name="${fieldName}"]`);
            if (field) {
                const value = field.value.trim();
                
                // Required field check
                if (rule.required && !value) {
                    isValid = false;
                    showError(field, rule.requiredMessage || '此字段为必填项');
                }
                // Min length check
                else if (rule.minLength && value.length < rule.minLength) {
                    isValid = false;
                    showError(field, rule.minLengthMessage || `最少需要${rule.minLength}个字符`);
                }
                // Regex pattern check
                else if (rule.pattern && !rule.pattern.test(value)) {
                    isValid = false;
                    showError(field, rule.patternMessage || '输入格式不正确');
                }
                // Custom validation function
                else if (rule.custom && typeof rule.custom === 'function' && !rule.custom(value)) {
                    isValid = false;
                    showError(field, rule.customMessage || '输入无效');
                }
                else {
                    clearError(field);
                }
            }
        });
        
        // Password match check (common use case)
        if (validationRules.password && validationRules.confirmPassword) {
            const password = form.querySelector('[name="password"]');
            const confirmPassword = form.querySelector('[name="confirm-password"]');
            
            if (password && confirmPassword && password.value !== confirmPassword.value) {
                isValid = false;
                showError(confirmPassword, '两次输入的密码不匹配');
            }
        }
        
        // If form is valid, submit it
        if (isValid) {
            if (validationRules.onSuccess && typeof validationRules.onSuccess === 'function') {
                validationRules.onSuccess(form);
            } else {
                form.submit();
            }
        }
    });
}

// Show error message for form field
function showError(field, message) {
    // Remove existing error
    clearError(field);
    
    // Create error element
    const errorElement = document.createElement('div');
    errorElement.className = 'text-red-500 text-xs mt-1';
    errorElement.textContent = message;
    
    // Add error class to field
    field.classList.add('border-red-500');
    
    // Insert error message after field
    field.parentNode.insertBefore(errorElement, field.nextSibling);
}

// Clear error message for form field
function clearError(field) {
    const existingError = field.parentNode.querySelector('.text-red-500');
    if (existingError) {
        existingError.remove();
    }
    
    field.classList.remove('border-red-500');
    field.classList.add('border-white/10');
}

// Toast Notification System
const toast = {
    show: function(message, type = 'info', duration = 3000) {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 translate-x-full`;
        
        // Apply styles based on type
        switch (type) {
            case 'success':
                toast.classList.add('bg-green-500', 'text-white');
                break;
            case 'error':
                toast.classList.add('bg-red-500', 'text-white');
                break;
            case 'warning':
                toast.classList.add('bg-yellow-500', 'text-white');
                break;
            default:
                toast.classList.add('bg-primary', 'text-white');
        }
        
        // Set message
        toast.textContent = message;
        
        // Add to DOM
        document.body.appendChild(toast);
        
        // Animate in
        setTimeout(() => {
            toast.classList.remove('translate-x-full');
            toast.classList.add('translate-x-0');
        }, 10);
        
        // Animate out and remove
        setTimeout(() => {
            toast.classList.remove('translate-x-0');
            toast.classList.add('translate-x-full');
            
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, duration);
    },
    
    success: function(message, duration) {
        this.show(message, 'success', duration);
    },
    
    error: function(message, duration) {
        this.show(message, 'error', duration);
    },
    
    warning: function(message, duration) {
        this.show(message, 'warning', duration);
    },
    
    info: function(message, duration) {
        this.show(message, 'info', duration);
    }
};

// Export for use in other files (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initMobileMenu,
        initSmoothScrolling,
        initFloatingAnimation,
        initParticleBackground,
        initInteractiveElements,
        validateForm,
        toast
    };
}